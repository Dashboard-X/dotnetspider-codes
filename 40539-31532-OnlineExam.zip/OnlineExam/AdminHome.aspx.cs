using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AdminHome : System.Web.UI.Page
{
    ConnectToDb mydb = new ConnectToDb();
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        //if (Session["uname"] == null)
        //    Response.Redirect("Admin_Login.aspx?ReturnUrl=AdminHome.aspx");
        if (!IsPostBack)
        {
            DataSet TestList=mydb.getTestList("viewtests");
            DataList1.DataSource = TestList;
            DataList1.DataBind();
        }

    }
    protected void LinkButton_Click(object sender, CommandEventArgs e)
    {
        Response.Redirect("Admin_view_test.aspx?Testnumber="+e.CommandArgument.ToString());
    }

    protected void Delete_Click(object sender, CommandEventArgs e)
    {
        //Delete test
        mydb.DropTest(e.CommandArgument.ToString());

        DataSet TestList = mydb.getTestList("viewtests");
        DataList1.DataSource = TestList;
        DataList1.DataBind();

    }


    protected void Button1_Click(object sender, EventArgs e)
    {

        try
        {
            System.Configuration.Configuration web = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration(Request.ApplicationPath);
            web.AppSettings.Settings.Remove("Delay");
            web.AppSettings.Settings.Add("Delay", "" + Convert.ToInt32(TextBox1.Text) * 1000 + "");
            web.Save(ConfigurationSaveMode.Modified);
        }
        catch(Exception Ex)
        {
            Response.Write("<script>alert(''" + Ex.Message + "'')</script>");
 
        }
    }
}