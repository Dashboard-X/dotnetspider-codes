using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class TestHome : System.Web.UI.Page
{
    ConnectToDb mydb = new ConnectToDb();
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        
        if (Session["mobieno"] == null)
            Response.Redirect("Home.aspx");

        if (!IsPostBack)
        {
            DataSet TestList = mydb.getTestList("GetTestList");
            DataList1.DataSource = TestList;
            DataList1.DataBind();
        }
    }
    protected void LinkButton_Click(object sender, CommandEventArgs e)
    {
        Response.Redirect("TakeTest1.aspx?testno=" + e.CommandArgument.ToString());
    }
}
