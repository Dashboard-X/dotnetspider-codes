using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class About_Us : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string text = "<P>Company Profile</p><br>" 
        //    + "We are Chennai based leading company engaged in supplying of electrical and automation systems for various industrial segments. Hindustan Automation Solutions has always been a customer oriented firm which makes sincere efforts to manufacture and supply latest and useful software and hardware for its valuable clientele across India. Today's world revolves around high technology & most companies have invested substantially in automated plants. For this reason most manufacturing companies are looking for competent engineers with basic aptitude towards automation and ability to work on varied brands of PLCs, Drives, MMI and SCADA. High levels of technical skills are required to keep it going in operations & maintenance. This prompted us to enter in this business domain.<br>" +
        //    "The company has been offering industrial automation/process automation, since its inception. We also provide trained manpower in PLC automation and after sales services to several industries at nominal charges. Apart from this, our centre in Chennai offers excellent training for engineering students, industry professionals, and freshers. We also conduct courses in the field of PLC & SCADA which are extremely useful for companies interested in automation trainings to update the skills of their technical persons, students undergoing summer training, working professionals engaged in project/maintenance/production/design/application engineering departments.<br>" +
        //    "<P>Our Mission:<br></P>" + 
        //    "To provide unique solutions in safety application domain.<br>" +
        //    "To offer all kinds of solutions in embedded processor technology.<br>" +
        //    "To provide total solution to our customers right from design, development, manufacture, supply, installation, and commissioning on turnkey basis.<br>" +
        //    "Manufacture and supply outstanding software and hardware at cost efficient prices.<br>" +
        //    "<P>Our Experts:<br></P>" +
        //    "Our expert team of professionals comprises of software and hardware engineers, R&D personnel, and other technocrats having mastery in embedded processor technology, process automation etc. We, at Hindustan Automation Solutions are known for our quality PLC & SCADA training and project related with software and hardware.<br>" +
        //    "Our dedicated and innovative team is the only reason for our huge success in this competitive market. Our people possess expertise in offering all sorts of after sales and services in industrial automation/process automation fields at cost effective prices to our clientele which is spread across the country. With their sincere and untiring efforts, we have gained a distinct position in this business domain. <br>" +
        //    "<P>Why Hindustan Automation Solutions:<br></P>" +
        //    "Experts in offering professional training services in engineering and management areas<br>" +
        //    "Consultancy services on engineering and technology practice management<br>" +
        //    "Reliability Analysis<br>" +
        //    "In-house embedded system R&D<br>" +
        //    "Product Engineering with PCB and mechanical design CAD facility<br>" +
        //    "Panel building and staging<br>" +
        //    "Training and projects for students and professionals as per their requirements.";
        ////Literal1.Text = text;
    }
}
