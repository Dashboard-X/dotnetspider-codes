using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Text;


public partial class TakeTest1 : System.Web.UI.Page
{
    static string sno, tno;
    static Int32 totalQs;
    static bool IsLastQs = false;
    ConnectToDb mydb = new ConnectToDb();
    static DataSet Questions;
    long timerStartValue = 1800;
    

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["mobieno"] == null)
        {
            Response.Write("<script>alert('Your Session Timer has Expired! We are Sorry!')</script>");
            Response.Redirect("Home.aspx");
        }

        if (!IsPostBack)
        {
            this.timerStartValue = long.Parse(ConfigurationManager.AppSettings["Delay"].ToString());
            this.TimerInterval = 500;
            tno = Request.QueryString["testno"].ToString();
            string query = "select * from questions where tnumber='" + tno + "'";
            Questions = mydb.GetDataSet(query);
            totalQs = mydb.GetCount(tno);
            LoadQuestion();

           
            DataSet questions = new DataSet("Questions");
            questions.Tables.Add();

        }
    }

    void Page_PreRender(object sender, EventArgs e)
    {
        StringBuilder bldr = new StringBuilder();
        bldr.AppendFormat("var Timer = new myTimer({0},{1},'{2}','timerData');", this.timerStartValue, this.TimerInterval, this.lblTimerCount.ClientID);
        bldr.Append("Timer.go()");
        ClientScript.RegisterStartupScript(this.GetType(), "TimerScript", bldr.ToString(), true);
        ClientScript.RegisterHiddenField("timerData", timerStartValue.ToString());
    }

    void Page_PreInit(object sender, EventArgs e)
    {
        string timerVal = Request.Form["timerData"];
        if (timerVal != null || timerVal == "")
        {
            timerVal = timerVal.Replace(",", String.Empty);
            timerStartValue = long.Parse(timerVal);
        }
    }

    private Int32 TimerInterval
    {
        get
        {
            object o = ViewState["timerInterval"];
            if (o != null) { return Int32.Parse(o.ToString()); }
            return 50;
        }
        set { ViewState["timerInterval"] = value; }

    }

    void RedirectToResults()
    {
        Response.Redirect("Results.aspx");
    }
  
    protected void LoadQuestion()
    {
        if (Questions.Tables[0].Rows.Count>0)
        {
            //Load Question;
            DataRow DR = Questions.Tables[0].Rows[0];
            
            Question.Text=DR[0].ToString()+" of "+totalQs;
            sno = DR[1].ToString();
            TestName.Text = DR[2].ToString();
            TestNo.Text = DR[3].ToString();

            Questionlbl.Text = DR[4].ToString();

            rbtnAns.Items.Clear();
            rbtnAns.Items.Add(DR[5].ToString());
            rbtnAns.Items.Add(DR[6].ToString());
            rbtnAns.Items.Add(DR[7].ToString());
            rbtnAns.Items.Add(DR[8].ToString());

            Questions.Tables[0].Rows.Remove(DR);

            if (Questionlbl.Text.Equals(totalQs.ToString()))
            {
                IsLastQs = true;
            }
        }
        else
        {
            //End Of File;
            //Response.Write("<script>alert('Thanks For Your Presence! You Can Leave Now.')</script>");
            Session.Abandon();
            RedirectToResults();
        }
    }




    protected void Button1_Click(object sender, EventArgs e)
    {
        
        try
        {
            //Write your code here to save the question

            //Displays the Next Question

            LoadQuestion();
        }
        catch(Exception ex)
        {
            Response.Write("<script>alert(''" + ex.Message + "'')</script>");
        }
       

        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //When Skip Button is pressed it loads the next question
        LoadQuestion();
    }
}
