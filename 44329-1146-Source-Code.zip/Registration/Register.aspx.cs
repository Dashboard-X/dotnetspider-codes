﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Net.Mail;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void CreateUserWizard1_SendingMail(object sender, MailMessageEventArgs e)
    {
        MembershipUser newUserAccount = Membership.GetUser(CreateUserWizard1.UserName);
        Guid newUserAccountId = (Guid)newUserAccount.ProviderUserKey;
        string domainName = Request.Url.GetLeftPart(UriPartial.Authority) + Request.ApplicationPath;
        string confirmationPage = "Confirm.aspx?memberID=" + newUserAccountId.ToString();
        string url = domainName + confirmationPage;
        e.Message.Body = e.Message.Body.Replace("<%VerificationUrl%>", url);
        SmtpClient smtp = new SmtpClient();

        smtp.Host = "smtp.gmail.com";
        smtp.Port = 587;
        smtp.UseDefaultCredentials = false;
        smtp.Credentials = new System.Net.NetworkCredential("admin@johnbhatt.com", "xxxxxxxx");
        smtp.EnableSsl = true;
        smtp.Send(e.Message);
        e.Cancel = true;
    }
}