﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Confirm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        Guid newUserId = new Guid(Request.QueryString["memberID"]);
        MembershipUser newUser = Membership.GetUser(newUserId);
        if (newUser == null)
        {
            Label1.Text = "User Account not found";
        }
        else
        {
            newUser.IsApproved = true;
            Membership.UpdateUser(newUser);
            Label1.Text = "Account Approved, please click <a href='Login.aspx' target='_self'>login</a> to continue";
        }
    }
}