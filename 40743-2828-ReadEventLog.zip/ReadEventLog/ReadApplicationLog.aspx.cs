﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Diagnostics;
public partial class ReadApplicationLog : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        GetSystemLogData();
    }

    public void GetSystemLogData()
    {
        DataTable objDt = new DataTable();
        //EventLog object from the Diagnostics namespace
        EventLog myLog = new EventLog();
        //Set the name of Log to read from
        myLog.Log = "System";
        myLog.MachineName = ".";

        //Check the number of Log entries
        int LogCount = myLog.Entries.Count;
        if (LogCount == 0)
            lblMsg.Text = "No Events Logged in the System Log";
        else
        {
            // Create a dataTable structure for DataSource
            objDt.Columns.Add("EntryType", typeof(string));
            objDt.Columns.Add("TimeGenerated", typeof(string));
            objDt.Columns.Add("Source", typeof(string));
            objDt.Columns.Add("EventID", typeof(string));
            objDt.Columns.Add("Message", typeof(string));
            objDt.Columns.Add("Category", typeof(string));
            //Check for entries of the Current Date
            for (int i = 0; i < LogCount; i++)
            {
                if (myLog.Entries[i].TimeGenerated.Date.ToShortDateString() == System.DateTime.Today.Date.ToShortDateString())
                {
                    DataRow dr = objDt.NewRow();
                    dr["EntryType"] = myLog.Entries[i].EntryType.ToString();
                    dr["TimeGenerated"] = myLog.Entries[i].TimeGenerated.ToString();
                    dr["Source"] = myLog.Entries[i].Source.ToString();
                    dr["EventID"] = myLog.Entries[i].EventID.ToString();
                    dr["Message"] = myLog.Entries[i].Message.ToString();
                    dr["Category"] = myLog.Entries[i].ToString();
                    objDt.Rows.Add(dr);
                }
            }

            //Bind the Data to the GridView
            GrdVw_SystemLog.DataSource = objDt;
            GrdVw_SystemLog.DataBind();


        }


    }
}
