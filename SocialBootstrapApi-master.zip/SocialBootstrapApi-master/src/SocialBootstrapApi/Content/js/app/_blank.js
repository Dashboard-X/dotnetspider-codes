(function (root)
{

})(window);
