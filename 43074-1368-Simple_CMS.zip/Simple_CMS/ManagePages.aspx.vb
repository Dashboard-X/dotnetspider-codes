﻿
Partial Class ManagePages
    Inherits System.Web.UI.Page

    Dim commFunc As New CommonFunctions
    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        SqlDataSource1.Insert()
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        SqlDataSource1.Update()
    End Sub

    Protected Sub DropDownList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DropDownList1.SelectedIndexChanged
        SqlDataSource1.FilterExpression = "pid=" & DropDownList1.SelectedValue
        Dim dv As Data.DataView = SqlDataSource1.Select(New DataSourceSelectArguments())
        UptxtPageTitle.Text = IIf(IsDBNull(dv.Item(0)(2)), "", dv.Item(0)(2))
        UptxtPageContent.Text = IIf(IsDBNull(dv.Item(0)(4)), "", dv.Item(0)(2))
        UptxtPageDescription.Text = IIf(IsDBNull(dv.Item(0)(3)), "", dv.Item(0)(2))
        UptxtPageKeywords.Text = IIf(IsDBNull(dv.Item(0)(5)), "", dv.Item(0)(2))
        UptxtPageName.Text = IIf(IsDBNull(dv.Item(0)(1)), "", dv.Item(0)(2))
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblPid.Text = commFunc.GetPageId()
    End Sub
End Class
