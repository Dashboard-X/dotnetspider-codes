﻿
Partial Class Pages
    Inherits System.Web.UI.Page

    Dim comfunc As New CommonFunctions
    Dim pageDet As New PageDetails

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Request.QueryString("id") <> Nothing Then
            Dim id As String = Request.QueryString("id")
            pageDet = comfunc.GetPageDetails(id)
            Me.Title = pageDet.PageTitle
            Me.MetaDescription = pageDet.PageDescription
            Me.MetaKeywords = pageDet.PageKeyword
            pagecontent.InnerHtml = pageDet.PageContent
        End If
    End Sub
End Class
