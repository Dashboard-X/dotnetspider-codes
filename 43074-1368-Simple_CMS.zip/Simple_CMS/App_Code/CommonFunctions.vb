﻿Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.VisualBasic

Public Class CommonFunctions

    Dim sqlcon As New SqlConnection(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)

    Public Function GetPageId() As String
        Dim dtap As New SqlDataAdapter("select * from Pages", sqlcon)
        Dim dt As New DataTable
        dtap.Fill(dt)
        Dim sid As Integer
        If dt.Rows.Count = 0 Then
            sid = 1
        Else
            Dim lst As Integer = dt.Rows(dt.Rows.Count - 1)(0)
            sid = lst + 1
        End If
        Return sid
    End Function

    Public Function GetPageNames() As Hashtable
        Dim dt As New DataTable
        Dim dtap As New SqlDataAdapter("select PageName from pages", sqlcon)
        dtap.Fill(dt)
        Dim arr As New Hashtable
        For Each row As DataRow In dt.Rows
            arr.Add(row(0), "Page-" & row(0).ToString().Replace(" ", "-") & ".aspx")
        Next
            Return arr
    End Function

    Public Function GetPageDetails(ByVal pagename As String) As PageDetails
        Dim dt As New DataTable
        Dim dtap As New SqlDataAdapter("select * from pages where pagename='" & pagename.Replace("-", " ") & "'", sqlcon)
        dtap.Fill(dt)

        Dim pagedet As New PageDetails
        pagedet.PageName = dt.Rows(0)(1)
        pagedet.PageTitle = dt.Rows(0)(2)
        pagedet.PageDescription = dt.Rows(0)(3)
        pagedet.PageContent = dt.Rows(0)(4)
        pagedet.PageKeyword = dt.Rows(0)(5)

        Return pagedet
    End Function

End Class

Public Class PageDetails
    Public Property PageTitle As String
    Public Property PageDescription As String
    Public Property PageKeyword As String
    Public Property PageName As String
    Public Property PageContent As String
End Class