﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class _Default
    Inherits System.Web.UI.Page

    Dim commFunc As New CommonFunctions

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        For Each strs As String In commFunc.GetPageNames().Keys
            Dim mItem As New MenuItem
            mItem.Text = strs
            mItem.NavigateUrl = commFunc.GetPageNames()(strs)
            Menu1.Items.Add(mItem)
        Next
    End Sub

End Class
